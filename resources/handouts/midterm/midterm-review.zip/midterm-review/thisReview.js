// in a function there are a couple of identifiers that come within scope
// arguments (an object that contains all args passed in as props/vals on obj)
// this <--- will vary on the way the function is invoked OR what kind of syntax is
// used to declare it

// method
// dot an object, invoke method
// arr = [] ... arr.push(...)
// this will refer to object that method was called on


function greeting(greeting, question) {
    console.log(greeting, this.first, question);
}
const person = {first: 'sej'};
person.hi = greeting;
// person.hi('hi', 'how are you?');



// regular func call, this is bound to global object
// greeting('hi', 'how are you?');


// call, apply, bind <-- does not invoke, instead returns a new function
// all methods on objects that are functions
// allows to set this explicitly
const person2 = {first: 'joe'};

greeting.call(person2, 'hello', 'how is it going????');
greeting.apply(person2, ['hello', 'how is it going????']);

// this withing greeting/greetJoe will always be person 2
const greetJoe = greeting.bind(person2);
greetJoe('hey', 'what is this about?');

const greetJoe2 = greeting.bind(person2, 'hola');
greetJoe2('what is this about?');





// arrow function
// new (as a constructor)
