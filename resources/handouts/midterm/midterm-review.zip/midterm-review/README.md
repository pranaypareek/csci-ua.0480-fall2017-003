These are mostly unedited notes from the midterm review on 10/10.

Use npm install to install the dependencies in package.json.
