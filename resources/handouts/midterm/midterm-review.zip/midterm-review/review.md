choose 2 out of 3 questions for the coding part
2 ~ 3 pages of short answer / what's output

* there will definitely be questions based on the homework 
    * those are the ones that will be coding quesitons
    * a coding question for express will def show up
    * there's partial credit
* a reference sheet provided:
    * express api
    * basic string, array methods
    * net module api
    * templating language
* read each q carefully for the coding ones... there will shortcuts
* no cookie
* no db



todo:

* add net module
* templating




* x oo x express
* x 16 x call/apply/bind
* x 10 x this
    * 15 - where's the error and why
* x 13 x the net module and order of execution
* x 12 x callbacks
* 11 x prototypes
    * type / inheritance
* 10 x closures
* 5 x hof 
* 3 x 17 - http query string
* 8 x hoisting


