const net = require('net');

// callback will be function called WHEN A CLIENT connects
const server = net.createServer(function(sock) {
    console.log('client connected');
    // only gets called when data is received
    sock.on('data', function(data) {
        console.log('received', data);
    });


})


console.log('before');
server.listen(3000, '127.0.0.1');
console.log('after');
