const express = require('express');
const app = express();
app.set('view engine', 'hbs');

const bodyParser = require('body-parser');

// gives us access to req.body (which is the parsed http request body)
// form url encoded .... name1=value1&name2=value2
app.use(bodyParser.urlencoded({extended: false}));

// add a comment saying: set up body parser
// add a comment saying: express static


// store in memory these snake names
const snakeNames = ['Python', 'Cobra', 'Hissy Elliot', 'Sir Hiss A lot'];

// add a snake name to a list of snake names
// allows you to filter based on length of the snake name

// use get to filter because we're only reading
app.get('/names', (req, res) => {
  // look in views folder for names.hbs
  // put in snake_names as var in template
  const maxLength = +req.query.maxLength || 40; 
  const filtered = snakeNames.filter(ele => ele.length < maxLength);

  res.render('names', {snakeNames: filtered, maxLength:maxLength, query: req.query});
});

app.post('/names', (req, res) => {
  snakeNames.push(req.body.snakeName);
  // we redirect without the query string
  res.redirect('/names');
});








app.listen(3000);






