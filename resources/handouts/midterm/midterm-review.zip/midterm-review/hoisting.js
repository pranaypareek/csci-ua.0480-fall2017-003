/*

foo();

function foo() {
    console.log('foo');
}


console.log(bar);

var bar = 'baz';

console.log(qux);
let qux = 'corge';
*/


/*
f();
var f = function() {};
*/



function f() {
    var g;

    function g() {
        console.log('g');    
    }

    console.log(g);
}

f();


{ // any block


    let a = 'a';
}






















