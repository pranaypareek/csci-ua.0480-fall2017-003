const express = require('express');
require('./db');
const bodyParser = require('body-parser');
const app = express();


const mongoose = require('mongoose');
const Cat = mongoose.model('Cat');

app.set('view engine', 'hbs');

app.use(bodyParser.urlencoded({ extended: false }));

/*
app.get('/', (req, res) => {
  Cat.find((err, cats, count) => {
    res.render('index', {cats: cats});
    }
  });
});
*/

app.get('/cats', function(req, res) {
  Cat.find(function(err, cats, count) {
    if(err) {
      res.send(err); 
    } 
    console.log('cats', cats);
    res.render( 'index', {
      cats: cats
    });
  });
});

app.listen(3000);
