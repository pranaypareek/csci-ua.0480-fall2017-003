// as always, require the module
const mongoose = require('mongoose'); 

// some extra stuff goes here...

// define the data in our collection
const Cat = new mongoose.Schema({
  name: String,
  updated_at: Date
});

// "register" it so that mongoose knows about it
mongoose.model('Cat', Cat);



// connect to the database (catdb)
mongoose.connect('mongodb://localhost/catdb');
