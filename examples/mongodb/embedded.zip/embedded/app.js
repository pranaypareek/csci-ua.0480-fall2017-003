const path = require('path');
const express = require('express');
const app = express();

// set templating engine to hbs
app.set('view engine', 'hbs');

// configure middleware: body parser and static files
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/pizza', (req, res) => {
  res.render('pizza-form', {}...);
});

app.post('/pizza/create', (req, res) => {
    const p = new Pizza({
    ...  
    })
    p.save((err, result, count) => {
        if(err) {
            res.render('/pizza-form', {errors: errors})
            // you can refresh, and it'll resubmit
            

            // redirect back to /pizza form
            res.redirect('/pizzas');
            // find some way of maintaining state between requests
            // so maybe dump the errors in the session
            // use session errors in /pizza and put them in context object
            // then clear session errors
        } else {
            res.redirect('/pizzas');
        }
    });
});







app.listen(3000);
