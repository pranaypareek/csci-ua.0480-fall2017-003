const mongoose = require('mongoose');
// url slugs will automaticall create a field
// called slug based on what you pass in to
// urlSlugs function
// urlSlugs('crust size')
// thin-medium-4
// YOU DO NOT HAVE TO EXPLICITLY DEFINE SLUG IN YOUR SCHEMA
// plugin takes care of it for you
const urlSlugs = require('mongoose-url-slugs');

// use ES6 native promise library
mongoose.Promise = global.Promise;

const ToppingSchema = new mongoose.Schema({
    name: String,
    extra: {type: Boolean, default: false},
});

//schema will define the props and types for every object in a collection
const PizzaSchema = new mongoose.Schema({
    // you can add more options by using a different syntax
    crust: String,
    // size: String,
    size: {type: String, enum: ['small', 'medium', 'large'], required: true},
    // slug???
    // defining embedded documents as a list...
    // create an array literal, and put in name of schema
    // toppings is an array of Topping documents
    toppings: [ToppingSchema]
});

// before registering models
PizzaSchema.plugin(urlSlugs('crust size'));

// model / constructor is being registered
// using some schema
mongoose.model("Pizza", PizzaSchema);
mongoose.model("Topping", ToppingSchema);


const Pizza = mongoose.model("Pizza");
// const Topping = mongoose.model("Topping");

/*
const p = new Pizza({
    crust: 'thin',
    size: 'medium'
});
const p = new Pizza({
    crust: 'thin',
    size: 'huge!!!!!'
});
*/

/*
p.save((err, result, count) => {
    console.log(err, result, count);
});
*/

Pizza.findOneAndUpdate({slug:'thin-medium-2'}, {$push: {toppings: {name:'peppers'}}}, function(err, pizza, count) {
      console.log(err, pizza, count);
});













// hostname, db name
// alternative ways to connect, which callback, since connect async
mongoose.connect('mongodb://localhost/class16', {useMongoClient: true});



/*
{
    crust: 'thin'
    size: 'medium'
    slug: 'medium-thin'
    toppings: [{name: 'pineapple', extra: false}, {name: 'chocolate', extra: true}]
}

{
    crust: 'deepdish'
    size: 'small'
    slug: 'small-deepdish'
    toppings: []
}

{
    crust: 'deepdish'
    size: 'small'
    slug: 'small-deepdish-2'
    toppings: []
}

*/
