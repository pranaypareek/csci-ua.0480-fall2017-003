// require, you'll npm install first
const express = require('express');

// create an express application object
// .set (to configure the app)
// .use (to use middleware, like express.static)
// http verbs / methods .get, .post, etc.
const app = express();


// configure app to use hbs
app.set('view engine', 'hbs');


// middleware function
// it is enabled by passing to
// app.use
// it has 3 params
// req, res
// next <-- is the next middleware func to
// call or the route handler
// every request call this function
app.use(express.static('public'));
app.use(function(req, res, next) {
   console.log(req.method, req.path); 
   next();
});

// express static middleware pseudocode
/*
app.use(function(req, res, next) {
    if req.path exists in file system
        res.send(req.path)
    else
        next()
});
*/

// install hbs
// create a directory called views
// create a layout for surrounding html
//
// create a template in views
// use res.render
app.get('/foo', (req, res) => {
  res.send('bar');
});

const numbers = [2, 4, 6, 8, 10, 12, 14, 16];
const nested = [[1, 3, 5], [8, 10, 12, 14, 16]];

app.get('/numbers', (req, res) => {
  res.render('numbers', {nums: numbers, nested:nested});
});

app.get('/objects', (req, res) => {
    // const point = {x:2, y:4};
    const points = [{x:2, y:4}, {x:3, y:7}];
  res.render('point', {points: points});
});


app.get('/', (req, res) => {
    // render will read a template file
    // and sub variables with the values w 
    // matching names in the second arg
    // which is the context object
    res.render('index', {greeting: "hello", thing: "cats"});
});


// we bind to a port
app.listen(3000);
