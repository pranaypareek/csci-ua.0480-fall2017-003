const express = require('express');
const app = express();
const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const bodyParser = require('body-parser');


// always parse request body as a string
app.use(bodyParser.urlencoded({ extended: false }));
// it gives us a req.body object that contains
// data from a form that sends a post request
// (data will be in body)



app.set('view engine', 'hbs');
// in express you can get parsed query string data
// by referencing the req.query object
app.get('/numbers', (req, res) => {
  const min = +req.query.min;
  const max = +req.query.max;
  const filteredNumbers = numbers.filter(n => n >= min && n <= max);
  console.log(req.query);
  res.render('numbers', {numbers: filteredNumbers});
});

app.get('/form', (req, res) => {
  res.render('form');
});
app.get('/success', (req, res) => {
  res.render('success', {numbers: numbers});
});

app.post('/form', (req, res) => {
    // don't render a template here, instead redirect
  numbers.push(+req.body.num);
  res.redirect('/success');
});

// when using post
// it's useful to do this:
// 1. 1 route to handle rendering the form
// 2. another route for the form post to redirect to
// 3. a 3rd route that actually accepts a post request


app.listen(3000);
